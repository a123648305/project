<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>
<center>
<body>

<div style="position:absolute; width: 668px; height: 389px; background-image: url(57.jpg); layer-background-image: url(57.jpg); border: 1px none #000000; left: 314px; top: 140px;">
  <p>
  <form action="denglu2.php" method="post" style="position:absolute; left: 17px; top: 19px; width: 647px; height: 352px;">
  <input name="tpa" type="password" id="tpa"  style="position:absolute; left: 132px; top: 247px; height: 27px; width: 185px;"/>
  <input name="tid" type="text" id="tid" style="position:absolute; left: 131px; top: 198px; height: 27px; width: 186px;"/>
   <input name="Submit" type="submit" style="position:absolute; left: 81px; top: 288px; width: 81px; height: 35px;" value="提交" />
   <input name="Submit" type="button" style="position:absolute; left: 206px; top: 286px; width: 77px; height: 39px;" onclick="window.location.href='main.php'"value="取消" />
  </p>
  </form>
  </div>
</body>
</center>
</html>
