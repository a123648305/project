<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<form action="information.php" method="post" style="position:absolute; width: 713px; left: 27px; top: 68px;" >
<p>&nbsp;</p>
<p>请输入你的订单号
  <input name="fid" type="text" id="fid" style="position:absolute; left: 164px; top: 38px; width: 267px; height: 47px;"/>
</p>
<p>&nbsp;</p>

  
  <input name="Submit" type="submit"style="position:absolute; left: 511px; top: 34px; width: 176px; height: 44px;"  value="查询"/>
  
  <input type="image" name="imageField" src="```````.jpg"  style="position:absolute; left: 1px; top: 296px; width: 706px;"/>
</p>
<div style="position:absolute; left: 751px; top: -19px; height: 757px; width: 446px; background-color: #FFFFFF; layer-background-color: #FFFFFF; border: 1px none #000000; background-image: url(tu.jpg); layer-background-image: url(tu
.jpg);"></div>
</form>
</body>
</html>
