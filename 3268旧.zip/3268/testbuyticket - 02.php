<!DOCTYPE HTML><head>
<title>buyticket</title>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<link href="/3248/css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="/3248/css/slider.css" rel="stylesheet" type="text/css" media="all"/>
<script type="text/javascript"  src="/3248/css/jquery-3.3.1.min.js"></script> 


<script type="text/javascript" src="js/jquery.nivo.slider.js"></script>

 <script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak=3cG0qwgGomENHQzmZqd6XOqXYBmYoGPm"></script>
<link  href="/3248/css/bootstrap.min.css" rel="stylesheet">


<script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    

	</script>
	
<!-- // 评价区CSS -->
	

	
	
</head>
<body>
			<div class="bear"><img src="images/robot.gif" width="102" height="181"></div>
			
			
		    <div  style="background: #FCFCFC;">
			<div class="showpost" >
			<table width="100%" border="0" cellspacing="10" cellpadding="0" id="main-tab1" ><h3 style="font-size:26px; color:#333"><b><center><?php echo $row_minformation['mname']; ?></center></b></h3>
			<tr><td width="16%"><span>
			  <h4>时长:<?php echo $row_minformation['mlong']; ?>分钟</h4></span></td><td width="15%"><span>
			  <h4>导演：<?php echo $row_minformation['mdirector']; ?></h4>
			  </span></td><td width="18%"><span>
			  <h4>类型：<?php echo $row_minformation['mchar']; ?></h4></span></td><td width="55%"><span>
			  <h4>主演：<?php echo $row_minformation['mperformer']; ?></h4>
			  </span></td></tr> </table>

<!-- //购票选择 -->
<!--//电影院选择-->
<div class="cinema"><p style="font-size:14px">温馨提示：此网站暂时只支持以下电影院，请在右上地图上查看所选电影院位置！</p><hr><ul>
	<li><span><input type="button" value="越界思哲IMAX(寮步店)" class="list"></span></li>
	<li><span><input type="button" value="橙天嘉禾影城(又一城店)" class="list2"></span></li>
	<li><span><input type="button" value="星美国际影城"></span></li></ul></div>
			
<p>
  <!-- //选择时间 --> 
</p>

<form name="gt" method="post" action="seat.php?m=帕丁顿熊2" >
<div  style="padding-left:100px; font-size:18px; background-color:#CCCCFF; margin-top:80px; ">观看时间
      <input name="tt" type="radio"  value=" <?php echo $ss['pdata']; ?> ">
      <?php echo $ss['pdata']; ?> </label>
  
      <
  </label></div><hr>

<!-- //场次选择	 --> 
<div>
			
			
	
    
    <table width="100%" border="0" cellspacing="0" cellpadding="0" id="main-tab" style="font-size:20px">
      <thead>
        <th width="30%"  align="center" valign="middle" class="borderright"  style="text-align:center"> 放映时间</th>
		
        <th width="16%" align="center" valign="middle" class="borderright" style="text-align:center">语言版本</th>
        <th width="16%" align="center" valign="middle" class="borderright" style="text-align:center">放映厅</th>
        
		<th width="15%" align="center" valign="middle" class="borderright" width:80px" style="text-align:center">售价</th>
        
        <th width="43%" align="center" valign="middle" style="text-align:center">选座购票</th>
      </thead>
	  <tbody>
     <!--<?php while($row_playlist = mysql_fetch_assoc($playlist)){?>
	 <tr onMouseOut="this.style.backgroundColor='#FCFCFC'" onMouseOver="this.style.backgroundColor='#edf5ff'">
        <td align="center" valign="middle" class="borderright borderbottom"> <?php echo $row_playlist['ptime']; ?></td>
        
        <td align="center" valign="middle" class="borderright borderbottom"><?php echo $row_playlist['mlanguage']; ?></td>
		<td align="center" valign="middle" class="borderright borderbottom"><?php echo $row_playlist['pid']; ?></td>
        <td align="center" valign="middle" class="borderright borderbottom">￥<?php echo $row_playlist['mprice']; ?></td>
        
		
        <td align="center" valign="middle" class="borderbottom"><input  type="submit" value="购买" class="btn btn-warning"></td>
      </tr>
      <?php }?>-->
	  </tbody>
    </table>
  
  </div>	
			
</th></form>			
	
	</div>	

<div style="text-align:center;">

<script>
$(".list").click(function(){
alert("showlist");

//var date;//获取日期
//var mid;//电影ID
$("palylist.json",function(data){
for(var i=0;i<data.length;i++){
	  var aa = "<tr><td>"+data[0].ptime+"</td>"
      +"<td>"+data[0].mlanguage+"</td>'
		+"<td>"+data[0].pid+'</td>"+"<td>￥"+data[i].mprice+"</td>"
     +"<td><input  type='submit' value='购买' class='btn btn-warning'></td></tr>";  
	  
	  $("tbody").append(aa);}});});
</script>
</body>
</html>
