<?php 
$a=$_POST['elist'].'ename';
//echo a.eid;
echo $a;
?>