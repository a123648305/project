<?php require_once('Connections/movie.php'); 


//error_reporting(0);
include('/header.php');
?>
<?php
mysql_select_db($database_movie, $movie);
$query_m1 = "SELECT movie.mname, movie.spicture, movie.mprice FROM movie WHERE movie.mid='1'";
$m1 = mysql_query($query_m1, $movie) or die(mysql_error());
$row_m1 = mysql_fetch_assoc($m1);
$totalRows_m1 = mysql_num_rows($m1);

mysql_select_db($database_movie, $movie);
$query_m2 = "SELECT * FROM movie WHERE movie.mid=2";
$m2 = mysql_query($query_m2, $movie) or die(mysql_error());
$row_m2 = mysql_fetch_assoc($m2);
$totalRows_m2 = mysql_num_rows($m2);

mysql_select_db($database_movie, $movie);
$query_m3 = "SELECT * FROM movie WHERE movie.mid=3";
$m3 = mysql_query($query_m3, $movie) or die(mysql_error());
$row_m3 = mysql_fetch_assoc($m3);
$totalRows_m3 = mysql_num_rows($m3);
?><!DOCTYPE HTML>
<head>
<title>Home</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<body>
<div class="header">
  <div class="wrap">
				<div class="header_top">
					<div class="logo">
						<a href="index.php"><img src="images/logo.png" alt="" /></a>
					</div>
						<div class="header_top_right">
						  
						 <div class="clear"></div>
				  </div>
				  <div class="search"><input type="search" placeholder="搜索"><input type="button" id="sok"></div>
						  <script type="text/javascript">
								function D<ropDown(el) {
									this.dd = el;
									this.initEvents();
								}
								DropDown.prototype = {
									initEvents : function() {
										var obj = this;
					
										obj.dd.on('click', function(event){
											$(this).toggleClass('active');
											event.stopPropagation();
										});	
									}
								}
					
								$(function() {
					
									var dd = new DropDown( $('#dd') );
					
									$(document).click(function() {
										// all dropdowns
										$('.wrapper-dropdown-2').removeClass('active');
									});
					
								});
					    </script>
			 <div class="clear"></div>
  		</div>     
				<div class="header_bottom">
					<div class="header_bottom_left">				
						<div class="categories">
						   <ul>
						  	   <h3>电影类型</h3>
							      <li><a href="#">全部</a></li>

							      
							      <li><a href="#">国语</a><ul>
								  <li><a href="http://www.baidu.com" >绣春刀</a></li>                   
 <li><a href="#" >战狼2</a></li>                   
 <li><a href="#" >英雄本色</a></li>                  
 
 </ul>  </li>
							      
								  
								  <li><a href="#">英语</a><ul><li><a href="#" >End Game</a></li>                   
 <li><a href="#" >AST</a></li>                   
  </ul></li>
		
							       <li><a href="#">儿童</a><ul><li><a href="buyticket.php" >烟火</a></li>                   
 <li><a href="#" >少女终末旅行</a></li>                   
  </ul></li>
								   
							       <li><a href="#">动物</a>
								   
								  <ul><li><a href=buyticket - 02.php"" >帕丁顿熊2</a></li>                   
 <li><a href="#" >小黄人</a></li>                   
 </ul> </li>
							       <li><a href="#">游戏</a></li>
					  	  </ul>
						</div>					
	  	          </div>
						    <div class="header_bottom_right">					 
						 	    <!------ Slider ------------>
								  <div class="slider">
							      	<div class="slider-wrapper theme-default">
							            <div id="slider" class="nivoSlider">
							                <img src="images/1.jpg" data-thumb="images/1.jpg" alt="" />
							                <img src="images/2.jpg" data-thumb="images/2.jpg" alt="" />
							                <img src="images/3.jpg" data-thumb="images/3.jpg" alt="" />
							                <img src="images/4.jpg" data-thumb="images/4.jpg" alt="" />
							                 <img src="images/5.jpg" data-thumb="images/5.jpg" alt="" />
											 <img src="images/5.jpg" data-thumb="images/6.jpg" alt="" />
							            </div>
							        </div>
						   		</div>
						<!------End Slider ------------>
			         </div>
			     <div class="clear"></div>
			</div>
  </div>
</div>
   <!------------End Header ------------>
  <div class="main">
  	<div class="wrap">
      <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>最新上映</h3>
    		</div>
    	</div>
	      <div class="section group">
				<div class="grid_1_of_5 images_1_of_5">
					 <a href="preview.html"><?php echo  "<img src='".$row_m1['spicture']."' alt='' />"?></a>
					 <h2><a href="preview.html"><?php echo $row_m1['mname']; ?></a></h2>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">￥<?php echo $row_m1['mprice']  ?></span></p>
				      </div>
					       		<div class="add-cart">								
									<h4><a href="buyticket - 02.php?mid=1">购票</a></h4>
				      </div>
							 <div class="clear"></div>
					</div>					 
				</div>
				<div class="grid_1_of_5 images_1_of_5">
					 <a href="preview.html"><?php echo  "<img src='".$row_m2['spicture']."' alt='' />"?></a>
					 <h2><a href="preview.html"><?php echo $row_m2['mname']; ?></a></h2>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">￥<?php echo $row_m2['mprice']; ?></span></p>
				      </div>
					       		<div class="add-cart">								
									<h4><a href="buyticket - 02.php?mid=2">购票</a></h4>
				      </div>
							 <div class="clear"></div>
					</div>
					 
				</div>
				<div class="grid_1_of_5 images_1_of_5">
					<a href="preview.html"><?php echo  "<img src='".$row_m3['spicture']."' alt='' />"?></a>
					 <h2><a href="preview.html"><?php echo $row_m3['mname']; ?></a></h2>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">￥<?php echo $row_m3['mprice']; ?></span></p>
				      </div>
					       		<div class="add-cart">								
									<h4><a href="buyticket - 02.php?mid=3">购票</a></h4>
				      </div>
							 <div class="clear"></div>
					</div>
				    
			</div>
				<div class="grid_1_of_5 images_1_of_5">
					<a href="preview.html"><img src="images/avatar_movie.jpg" alt="" /></a>
					 <h2><a href="preview.html">Avatar</a></h2>
					 <div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">￥32</span></p>
				       </div>
					       		<div class="add-cart">								
									<h4><a href="preview.html?mid=4">购票</a></h4>
				       </div>
							 <div class="clear"></div>
					</div>
				</div>
				<div class="grid_1_of_5 images_1_of_5">
					<a href="preview.html"><img src="images/black-swan.jpg" alt="" /></a>
					 <h2><a href="preview.html">Black Swan</a></h2>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">￥35</span></p>
				      </div>
					       		<div class="add-cart">								
									<h4><a href="preview.html">购票</a></h4>
				      </div>
							 <div class="clear"></div>
					</div>				     
				</div>
		</div>
			<div class="content_bottom">
    		<div class="heading">
    		<h3>即将上映</h3>
    		</div>
    	  </div>
			<div class="section group">
				<div class="grid_1_of_5 images_1_of_5">
					 <a href="preview.html"><img src="images/beauty_and_the_beast.jpg" alt="" /></a>
					 <h2><a href="preview.html">Beauty and the beast</a></h2>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">12月15日上映</span></p>
				      </div>
					       		<div class="add-cart">								
									<h4><a href="#">想看</a></h4>
				      </div>
							 <div class="clear"></div>
					</div>
					 
				</div>
				<div class="grid_1_of_5 images_1_of_5">
					 <a href="preview.html"><img src="images/Eclipse.jpg" alt="" /></a>
					 <h2><a href="preview.html">Eclipse</a></h2>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">12月15日上映</span></p>
				      </div>
					       		<div class="add-cart">								
									<h4><a href="#">想看</a></h4>
				      </div>
							 <div class="clear"></div>
					</div>
					 
				</div>
				<div class="grid_1_of_5 images_1_of_5">
					<a href="preview.html"><img src="images/Coraline.jpg" alt="" /></a>
					 <h2><a href="preview.html">Coraline</a></h2>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">12月15日上映</span></p>
				      </div>
					       		<div class="add-cart">								
									<h4><a href="#">想看</a></h4>
				      </div>
							 <div class="clear"></div>
					</div>
				    
				</div>
				<div class="grid_1_of_5 images_1_of_5">
					<a href="preview.html"><img src="images/Unstoppable.jpg" alt="" /></a>
					 <h2><a href="preview.html">正义联盟</a></h2>
					 <div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">12月15日上映</span></p>
				       </div>
					       		<div class="add-cart">								
									<h4><a href="#">想看</a></h4>
				       </div>
							 <div class="clear"></div>
					</div>
				</div>
				<div class="grid_1_of_5 images_1_of_5">
					<a href="preview.html"><img src="images/Priest.jpg" alt="" /></a>
					 <h2><a href="preview.html">英雄本色</a></h2>
					<div class="price-details">
				       <div class="price-number">
							<p><span class="rupees">12月16日上映</span></p>
				      </div>
					       		<div class="add-cart">								
									<h4><a href="#">想看</a></h4>
				      </div>
							 <div class="clear"></div>
				  </div>				     
				</div>
			</div>
      </div>
  </div>
</div>
<div class="bear"><img src="images/robot.gif" width="102" height="181"></div>
   <?php include("/footer.php");?>
    <script type="text/javascript">
		$(document).ready(function() {			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop"><span id="toTopHover"> </span></a>
<div style="display:none"><script src='http://v7.cnzz.com/stat.php?id=155540&web_id=155540' language='JavaScript' charset='gb2312'></script>
</div>
</body>
</html><?php
mysql_free_result($m1);

mysql_free_result($m2);

mysql_free_result($m3);
?>